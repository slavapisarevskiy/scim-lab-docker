# Purpose
This directory contains the data that is required to customize PingFederate containers to taste
The file system structure must follow that of a pingfederate instance.
These files are laid over a vanilla installation of pingfederate

## Credentials
User: Administrator
Password: 2FederateM0re ( that's a zero numeral, not uppercase O )
