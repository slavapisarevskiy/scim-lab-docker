ALTER TABLE channel_group MODIFY saasGroupName VARCHAR2(4000) NULL;
