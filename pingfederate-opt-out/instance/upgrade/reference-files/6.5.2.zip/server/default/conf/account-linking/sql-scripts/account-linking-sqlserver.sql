
# ------------------------------------------------------------
# Create table pingfederate_account_link
# ------------------------------------------------------------

CREATE TABLE pingfederate_account_link(
    idp_entityid    VARCHAR(256),
    external_userid VARCHAR(256),
    adapter_id      VARCHAR(32),
    local_userid    VARCHAR(256),
    date_created    DATETIME NOT NULL,
    CONSTRAINT pk_account PRIMARY KEY (idp_entityid, external_userid, adapter_id)
);
CREATE INDEX LOCALUSERIDIDX ON pingfederate_account_link(local_userid);

GO